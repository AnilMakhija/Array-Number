import UIKit

var greeting = "Hello, playground"
func findHigestNumber(in array:[Int]) -> Int?{
    guard !array.isEmpty else {
        return nil
    }
    var higestnumber = array[0]
    
    for number in array{
        if number > higestnumber{
            higestnumber = number
        }
    }
    return higestnumber
    
}

let mylist = [33,23,76,12,74,34,2,5,78]
if let number = findHigestNumber(in: []){
    print("Higest number ==>",number)
}else {print("array is empty")}



// Find lowest number
func findLowestNumber(array:[Int]) -> Int?{
    guard !array.isEmpty else {
        return nil
    }
    
    var lowestnumber = array[0]
    for number in array {
        if number < lowestnumber {
            lowestnumber = number
        }
    }
    return lowestnumber
}

let numberArray = [111,23,76,12,74,34,2,5,1]
if let number = findLowestNumber(array: numberArray){
    print("Lowest number ==>",number)
}else {print("Empty array")}


 //find numbers higher from 20

func findHigherNumberfromTen(array:[Int]) -> [Int]?{
    guard !array.isEmpty else {
        return nil
    }
    
    var highernumbers = [Int]()
    for number in array {
        if number > 20 {
            highernumbers.append(number)
        }
    }
    return highernumbers
    
}

let numbers = [33,55,77,11,77,22,334,12,13,54,76,12,14]
print("numbers higher then 20==>",findHigherNumberfromTen(array: numbers) as Any)

//Find EvenNumbers from array
func findEvenNumbers(array:[Int]) -> [Int]?{
    guard !array.isEmpty else{
        return nil
    }
    
    var evenNumbers = [Int]()
    for number in array{
        if (number % 2 == 0){
            evenNumbers.append(number)
        }
    }
    return evenNumbers
}

let numbers = [23,54,76,98,23,67,98,99,23,11,22,33,45]
if let allEvennumbers = findEvenNumbers(array: numbers){
    print("Even numbers==>\(allEvennumbers)")
} else {print("Empty array")}


//Find OddNumbers from array
func findOddNumbers(array:[Int]) -> [Int]? {
    guard !array.isEmpty else {
        return nil
    }
    
    var oddNumbers = [Int]()
    for number in array {
        if (number % 2 != 0)  {
            oddNumbers.append(number)
        }
    }
    return oddNumbers
}

let numbers = [23,65,87,2,42,76,14,97,44]
if let odd = findOddNumbers(array: numbers) {
    print("Odd numbers\(odd)")
}else {print("empty array")}


// print prime numbers from 1 to 100
func findPrimeNumbers() -> [Int]{
    
    var primes = [Int]()
    for number in 1...100 {
        if isPrime(n: number){
            primes.append(number)
        }
    }
    return primes
}

func isPrime(n:Int) -> Bool{
    guard n > 1 else {return false}
    for i in 2..<n {
        if n % 2 == 0{
            return false
        }
    }
    return true
}

print("Prime numbers==>",findPrimeNumbers())

//fibonacci numbers
func fibonacciNumbers() -> [Int] {
    var fibo = [Int]()
    var a = 0
    var b = 1
    
    while a <= 100 {
        fibo.append(a)
        let next = a + b
        a = b
        b = next
    }
    return fibo
}

print("fibonacci numbers==>",fibonacciNumbers())


//How do you find all pairs of an integer array whose sum is equal to a given number?
func findPairsWithSum(array:[Int], targetSum:Int) -> [(Int, Int)] {
    var pairs: [(Int, Int)] = []
//    var seenNumber: Set<Int> = []
//
//    for number in array{
//        let complement = targetSum - number
//        if seenNumber.contains(complement){
//            pairs.append((complement,number))
//        }
//        seenNumber.insert(number)
//    }
//    return pairs
    var foundPairs:[(Int, Int)] = []
    for i in 0..<array.count{
        for j in i + 1..<array.count{
            if array[i] + array [j]  == targetSum{
                foundPairs.append((array[i],array[j]))
            }
        }
    }
    return foundPairs
}

// Example usage:
let numbers = [1, 2, 3, 4, 5, 6]
let targetSum = 7
let pairs = findPairsWithSum(array: numbers, targetSum: targetSum)
print(pairs) // Output: [(3, 4), (2, 5), (1, 6)]


//How do you remove duplicates from an array in place?
//How do you find duplicates from an unsorted array?
func removeDuplicates(array: [Int]) -> [Int]? {
    guard !array.isEmpty else { return nil }
    var uniqueElements: [Int] = []
    for number in 1..<array.count {
        if !uniqueElements.contains(number){
            uniqueElements.append(number)
        }
    }

    return uniqueElements
}

var numbers = [1, 2, 3, 4, 5, 4, 6, 7, 8, 8]
if let newLength = removeDuplicates(array: numbers){
    print(newLength)
}else {print("Empty array")}


//How to rotate an array left and right by a given number K?
//Suppose, you were given an integer array [1, 2, 3, 4, 5, 6, 7, 8] and asked to rotate left by 4 and then rotate right by 4. Write a program to accomplish array rotation by left and right.
func rotateArray(array:[Int]) -> [Int]? {
    guard !array.isEmpty else { return nil }
    var newarray = [Int]()
    for i in 0..<array.count {
        if array[i] == 4 {
            newarray.append(array[i+1])
        }
    }
    newarray.append(4)
    for i in 0..<array.count {
        if array[i] != 4 {
            newarray.append(array[i])
        }
    }
    return newarray
}

let myarray = [1, 2, 3, 4, 5, 6, 7, 8]
if let new = rotateArray(array: myarray){
    print(new)
}else {print("Empty array")}


//palindromes numbers
func ispalindrome(_number:Int) ->Bool{
    let str = String(_number)
    return str == String(str.reversed())
}

func firstNPalindromes(count:Int) -> [Int]?{
    guard count > 1 else { return nil }
    
    var palindromes = [Int]()
    var number = 0
    
    while palindromes.count < count{
        if (ispalindrome(_number:number )){
            palindromes.append(number)
        }
        number += 1
    }
    return palindromes
    
}

if let palindrome = firstNPalindromes(count: 100){
    print(palindrome)
}else {print("count 0")}


//Program to convert a given number to words
func convertNumberToWords(_ number: Int) -> String {
    guard number >= 0 else { return "Negative numbers are not supported." }
    
    if number == 0 {
        return "Zero"
    }
    
    let units: [String] = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"]
    let teens: [String] = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
    let tens: [String] = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]
    let thousands: [String] = ["", "Thousand", "Million", "Billion"]

    func numberToWords(_ num: Int) -> String {
        var result = ""
        
        if num >= 100 {
            result += units[num / 100] + " Hundred "
        }

        let remainder = num % 100
        if remainder >= 20 {
            result += tens[remainder / 10] + " "
            result += units[remainder % 10] + " "
        } else if remainder >= 10 {
            result += teens[remainder - 10] + " "
        } else if remainder > 0 {
            result += units[remainder] + " "
        }
        
        return result.trimmingCharacters(in: .whitespaces) // Remove extra spaces
    }
    
    var words = ""
    var tempNumber = number
    var thousandIndex = 0
    
    while tempNumber > 0 {
        let part = tempNumber % 1000
        if part > 0 {
            let partInWords = numberToWords(part) // Call the function without naming conflict
            words = partInWords + (thousands[thousandIndex] != "" ? " " + thousands[thousandIndex] : "") + " " + words
        }
        tempNumber /= 1000
        thousandIndex += 1
    }
    
    return words.trimmingCharacters(in: .whitespaces) // Remove extra spaces
}

// Example usage
let number = 123456789
let words = convertNumberToWords(number)
print(words) // Output: "One Hundred Twenty Three Million Four Hundred Fifty Six Thousand Seven Hundred Eighty Nine"
